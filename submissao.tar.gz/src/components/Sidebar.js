
// import styles from "../styles/Sidebar.module.css"
// import { Link } from "react-router-dom";

// export function Sidebar({ buttons }) {
//     return (
//         <div className={styles.main}>
//             {buttons.map((b, i) => (
//                 <Link to={b.id}>
//                     <Button key={i}>
//                         {b.text}
//                     </Button>
//                 </Link>
//             ))}
//         </div>
//     )
// }

// export function Button({ children, onClick, ...props }) {
//     return <button onClick={onClick}>{children}</button>
// }